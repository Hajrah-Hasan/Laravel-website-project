@extends('hi')
@section('content')
<div class="row bg " style=" background-size:cover; color:black;  background-attachment: fixed;o background-repeat: no-repeat;" class="col bg text-dark text-center ">

  <div style="opacity: 0.5; background-color: rgb(20, 33, 33); background-size:cover; color:black;  background-attachment: fixed;o background-repeat: no-repeat;" class="col  text-center ">
   <p  class="fs-sm-1  " style=" color:white; font-size:12.5vh;  padding-top: 15%; padding-bottom:11%; 
 font-family: Georgia, serif;
 
" > Menu</p> 

  </div>
</div> 
<div class="row"style="background-image: url(images/;">
  <div class="col-sm-12 text-center fs-1" >
    <b style="color: brown ;font-weight:bold;" style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"  class="fs-4 ">  <br> Food Menu</b>
 <br> <b style="font-family: Georgia, serif;" >Most Popolar Items </b> <br>  </div> 
  <div class="row mt-sm-3 mt-5  text-center mx-auto px-5">
    <div class="col-md-6 mt-sm-3  " style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class=" pt-sm-2   fs-4 d-inline text-decoration-underline">Behari Kabab Pizza  </p> <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">1000Rs <br></p>
      Roasted duck breast (served pink) with gratin potato and a griottine cherry sauce
      
      </div>
    <div class="col-md-6 mt-sm-3 " style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 d-inline text-decoration-underline ">Mayu Garlic Pizza </p> <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">1000Rs</p> <br>
      Cod, haddock, prawn and salmon in a creamy white wine and leek sauce, topped with mash potato and Gruyère cheese</div>
    <div class="col-md-6 mt-sm-3 "><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 text-decoration-underline d-inline"> PH Special Pizza  </p>  <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">1000Rs</p><br>
      Chargrilled chicken with avocado, baby gem lettuce, baby spinach, shallots, French beans, walnuts, croutons and a mustard dressing
      
      </div>
    <div class="col-md-6 mt-sm-3 "style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 text-decoration-underline d-inline">Malai Boti Pizza</p>  <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">1000Rs</p> <br>
      Chargrilled fresh tuna steak (served medium rare) on classic Niçoise salad with French beans, cherry tomatoes, black olives, peppers, new potatoes, egg, baby gem lettuce and red onion
      
      </div>
    <div class="col-md-6 mt-sm-3 "style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 d-inline text-decoration-underline">Achari PIzza  </p><p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">1000Rs</p> <br>
      Cod, haddock, prawn and salmon in a creamy white wine and leek sauce, topped with mash potato and Gruyère cheese</div>
    <div class="col-md-6 mt-sm-3 "style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 d-inline text-decoration-underline">PH Special Platter</p>  <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">450Rs</p> <br>
      Cod, haddock, prawn and salmon in a creamy white wine and leek sauce, topped with mash potato and Gruyère cheese</div>
    <div class="col-md-6 mt-sm-3 "style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 d-inline  text-decoration-underline">Jalapeno Cheese Stick</p>  <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">300Rs</p> <br>
      Cod, haddock, prawn and salmon in a creamy white wine and leek sauce, topped with mash potato and Gruyère cheese</div>
    <div class="col-md-6 mt-sm-3 "style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 d-inline text-decoration-underline">Oven Baked Wings</p>  <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">400Rs</p> <br>
      Cod, haddock, prawn and salmon in a creamy white wine and leek sauce, topped with mash potato and Gruyère cheese</div>
    <div class="col-md-6 mt-sm-3 "style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 d-inline text-decoration-underline">Lasagna </p>  <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">650Rs</p> <br>
      Cod, haddock, prawn and salmon in a creamy white wine and leek sauce, topped with mash potato and Gruyère cheese</div>
    <div class="col-md-6 mt-sm-3 "style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif"><p style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif" class="fs-4 d-inline text-decoration-underline">Oven Flame Pasta </p>  <p style="color: brown ;font-weight:bold;  display:inline; padding-left:14%;">400Rs</p> <br>
      Cod, haddock, prawn and salmon in a creamy white wine and leek sauce, topped with mash potato and Gruyère cheese</div>
    
    <div class="col-sm-12 px-auto">
      <br>
     <a href="/shop"> <button type="button" class="btn btn-outline-dark border-2 px-4  fw-bold">EXPLORE FULL MENU</button></a>
    </div>
  </div>
</div> 
<br>
@endsection